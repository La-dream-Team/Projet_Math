
package BFS;

public enum Color {
    GREEN, ORANGE, RED
}
